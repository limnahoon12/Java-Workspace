package com.kh.example.practice4.run;

public class Run {

	public static void main(String[] args) {
		
	}
}
