package com.kh.example.practice5.model.vo;

public class Lotto {

}
