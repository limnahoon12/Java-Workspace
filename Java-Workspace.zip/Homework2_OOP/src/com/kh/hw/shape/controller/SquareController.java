package com.kh.hw.shape.controller;

import com.kh.hw.shape.model.vo.Shape;

public class SquareController {
	
	private Shape p = new Shape();
	
	public  double calcPerimeter(double height, double width) {
		p.setHeight(height);
		p.setWidth(width);
		return (height*2)+(width*2);
		
	}
	public double calcArea(double height, double width) {
		p.setHeight(height);
		p.setWidth(width);
		return (height + width);
	}
	
	public  void paintColor(String color) {
		p.setColor(color);
	}
	public String print() {
		return p.information();
	}
}
