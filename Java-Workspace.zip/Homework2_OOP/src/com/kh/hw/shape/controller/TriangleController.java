package com.kh.hw.shape.controller;

import com.kh.hw.shape.model.vo.Shape;

public class TriangleController {
	
	private Shape p = new Shape();
	public double calcArea(double height ,double width) {
		p.setHeight(height);
		p.setWidth(width);
		return (width * height);
		
	}
	
	public  void paintColor(String color) {
		p.setColor(color);
	}

	public String print() {
		return p.information();
	}


















}

