package com.kh.practice.run;

import com.kh.array.*;

public class Run {
	public static void main(String[] args) {
		ArrayPractice ap= new ArrayPractice();
		//ap.practice1();
		//ap.practice2();
		B_ArrayCopy bac = new B_ArrayCopy ();
		//bac.method5();
		C_DimensionalArray cda = new C_DimensionalArray();
		//cda.method1();
		//cda.method2();
		//cda.method3();
		//cda.method4();
		cda.method7();
	}
	
}

