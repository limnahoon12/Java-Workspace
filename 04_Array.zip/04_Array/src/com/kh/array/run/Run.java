package com.kh.array.run;

import com.kh.array.A_Array;

public class Run {
	public static void main(String[] args) {
		A_Array aa = new A_Array();
		//aa.method1();
		//aa.method2();
		//a.method4();
		//aa.method5();
		//aa.method6();
		//aa.method8();
		aa.method11();
	
	
	}
}
