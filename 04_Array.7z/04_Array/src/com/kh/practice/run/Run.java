package com.kh.practice.run;

import com.kh.array.ArrayPractice;

public class Run {
	public static void main(String[] args) {
		ArrayPractice ap= new ArrayPractice();
		//ap.practice1();
		ap.practice2();
	}
}
